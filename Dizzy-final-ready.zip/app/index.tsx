import React, { useState } from 'react';
import { Alert, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '../lib/supabase';

export default function Index() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  async function signIn() {
    if (!supabase) {
      router.replace('/home');
      return;
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) Alert.alert('Dizzy', error.message);
    else router.replace('/home');
  }

  async function signUp() {
    if (!supabase) {
      router.replace('/home');
      return;
    }
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) Alert.alert('Dizzy', error.message);
    else Alert.alert('Готово', 'Проверь почту для подтверждения.');
  }

  return (
    <SafeAreaView style={s.safe}>
      <View style={s.container}>
        <View style={s.logo}><Text style={s.logoText}>D</Text></View>
        <Text style={s.title}>Dizzy</Text>
        <Text style={s.subtitle}>Общайся проще.</Text>
        <TextInput placeholder="Email" placeholderTextColor="#777" value={email} onChangeText={setEmail} style={s.input} autoCapitalize="none" keyboardType="email-address" />
        <TextInput placeholder="Пароль" placeholderTextColor="#777" value={password} onChangeText={setPassword} style={s.input} secureTextEntry />
        <Pressable style={s.button} onPress={signIn}><Text style={s.buttonText}>Войти</Text></Pressable>
        <Pressable style={s.secondary} onPress={signUp}><Text style={s.secondaryText}>Создать аккаунт</Text></Pressable>
        <Pressable onPress={() => router.replace('/home')}><Text style={s.demo}>Продолжить в демо-режиме</Text></Pressable>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:{flex:1,backgroundColor:'#0B0B0F'}, container:{flex:1,justifyContent:'center',padding:24},
  logo:{width:72,height:72,borderRadius:22,backgroundColor:'#7C5CFF',alignItems:'center',justifyContent:'center',alignSelf:'center',marginBottom:18},
  logoText:{fontSize:42,fontWeight:'900',color:'#fff'}, title:{fontSize:40,fontWeight:'900',color:'#fff',textAlign:'center'},
  subtitle:{fontSize:16,color:'#999',textAlign:'center',marginBottom:38}, input:{height:54,borderRadius:16,backgroundColor:'#17171D',paddingHorizontal:18,color:'#fff',marginBottom:12},
  button:{height:54,borderRadius:16,backgroundColor:'#7C5CFF',alignItems:'center',justifyContent:'center',marginTop:8},
  buttonText:{color:'#fff',fontSize:16,fontWeight:'800'}, secondary:{height:54,borderRadius:16,borderWidth:1,borderColor:'#292933',alignItems:'center',justifyContent:'center',marginTop:10},
  secondaryText:{color:'#fff',fontSize:16,fontWeight:'700'}, demo:{color:'#7C5CFF',textAlign:'center',marginTop:24,fontWeight:'700'}
});