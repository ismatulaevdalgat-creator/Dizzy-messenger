import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';

export default function Chat() {
  const [value,setValue]=useState('');
  const [messages,setMessages]=useState([
    {id:'1',text:'Привет! 👋',mine:false},{id:'2',text:'Привет! Это Dizzy.',mine:true}
  ]);
  function send(){
    if(!value.trim()) return;
    setMessages([...messages,{id:String(Date.now()),text:value.trim(),mine:true}]);
    setValue('');
  }
  return <SafeAreaView style={s.safe}>
    <View style={s.top}><Pressable onPress={()=>router.back()}><Text style={s.back}>‹</Text></Pressable><View><Text style={s.name}>Alex</Text><Text style={s.online}>в сети</Text></View><View style={{flex:1}}/></View>
    <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
      <FlatList data={messages} keyExtractor={x=>x.id} contentContainerStyle={{padding:16}} renderItem={({item})=>
        <View style={[s.bubble,item.mine?s.mine:s.theirs]}><Text style={s.msg}>{item.text}</Text></View>
      }/>
      <View style={s.composer}><TextInput value={value} onChangeText={setValue} placeholder="Сообщение..." placeholderTextColor="#777" style={s.input}/><Pressable style={s.send} onPress={send}><Text style={s.sendText}>➤</Text></Pressable></View>
    </KeyboardAvoidingView>
  </SafeAreaView>
}
const s=StyleSheet.create({
safe:{flex:1,backgroundColor:'#0B0B0F'},top:{height:68,paddingHorizontal:16,flexDirection:'row',alignItems:'center',gap:12,borderBottomWidth:1,borderBottomColor:'#18181F'},back:{color:'#fff',fontSize:40,fontWeight:'300'},name:{color:'#fff',fontSize:17,fontWeight:'800'},online:{color:'#25C78A',fontSize:12,marginTop:2},bubble:{maxWidth:'78%',paddingHorizontal:15,paddingVertical:11,borderRadius:18,marginBottom:8},mine:{backgroundColor:'#7C5CFF',alignSelf:'flex-end',borderBottomRightRadius:5},theirs:{backgroundColor:'#1A1A21',alignSelf:'flex-start',borderBottomLeftRadius:5},msg:{color:'#fff',fontSize:15},composer:{flexDirection:'row',padding:10,gap:8,borderTopWidth:1,borderTopColor:'#18181F'},input:{flex:1,height:48,borderRadius:16,backgroundColor:'#17171D',paddingHorizontal:16,color:'#fff'},send:{width:48,height:48,borderRadius:16,backgroundColor:'#7C5CFF',alignItems:'center',justifyContent:'center'},sendText:{color:'#fff',fontSize:20}
});