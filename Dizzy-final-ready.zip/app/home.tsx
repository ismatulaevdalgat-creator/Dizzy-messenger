import React from 'react';
import { FlatList, Pressable, SafeAreaView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';

const chats = [
  { id:'1', name:'Alex', text:'Увидимся вечером?', time:'14:32', color:'#FF6B6B' },
  { id:'2', name:'Dizzy Team', text:'Новый дизайн уже готов 🔥', time:'13:08', color:'#7C5CFF' },
  { id:'3', name:'Masha', text:'Спасибо! ❤️', time:'Вчера', color:'#25C78A' },
];

export default function Home() {
  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <View><Text style={s.brand}>Dizzy</Text><Text style={s.caption}>Сообщения</Text></View>
        <Pressable style={s.plus} onPress={() => router.push('/chat')}><Text style={s.plusText}>＋</Text></Pressable>
      </View>
      <FlatList data={chats} keyExtractor={x=>x.id} contentContainerStyle={{padding:16}} renderItem={({item})=>(
        <Pressable style={s.row} onPress={() => router.push('/chat')}>
          <View style={[s.avatar,{backgroundColor:item.color}]}><Text style={s.avatarText}>{item.name[0]}</Text></View>
          <View style={s.mid}><Text style={s.name}>{item.name}</Text><Text style={s.text} numberOfLines={1}>{item.text}</Text></View>
          <Text style={s.time}>{item.time}</Text>
        </Pressable>
      )}/>
    </SafeAreaView>
  );
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#0B0B0F'},header:{paddingHorizontal:20,paddingTop:12,paddingBottom:10,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
 brand:{color:'#fff',fontSize:32,fontWeight:'900'},caption:{color:'#777',marginTop:2},plus:{width:42,height:42,borderRadius:14,backgroundColor:'#7C5CFF',alignItems:'center',justifyContent:'center'},plusText:{color:'#fff',fontSize:28,lineHeight:30},
 row:{flexDirection:'row',alignItems:'center',paddingVertical:13},avatar:{width:54,height:54,borderRadius:18,alignItems:'center',justifyContent:'center'},avatarText:{color:'#fff',fontSize:22,fontWeight:'800'},
 mid:{flex:1,marginLeft:14},name:{color:'#fff',fontSize:16,fontWeight:'800',marginBottom:4},text:{color:'#8B8B95',fontSize:14},time:{color:'#666',fontSize:12,alignSelf:'flex-start',marginTop:4}
});