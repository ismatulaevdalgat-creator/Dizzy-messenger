# Dizzy Messenger

Clean Expo SDK 54 Android project.

## Versions
- Expo SDK 54
- React 19.1.0
- React Native 0.81.5
- Expo Router 6.0.24

## Build
The included GitHub Actions workflow builds:
`android/app/build/outputs/apk/release/app-release.apk`

The APK is uploaded as the `Dizzy-APK` artifact.
