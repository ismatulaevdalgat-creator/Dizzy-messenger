# Dizzy — MVP

## Самый быстрый запуск

1. Установи Node.js LTS.
2. Распакуй проект.
3. В терминале в папке проекта:
   `npm install`
4. Для демо:
   `npx expo start`
5. Отсканируй QR-код приложением Expo Go.

## Подключение Supabase

1. Создай проект в Supabase.
2. Открой SQL Editor и выполни `supabase/schema.sql`.
3. Скопируй `.env.example` в `.env`.
4. Заполни `EXPO_PUBLIC_SUPABASE_URL` и `EXPO_PUBLIC_SUPABASE_ANON_KEY`.
5. Перезапусти Expo.

Сейчас UI работает и без Supabase в демо-режиме. После подключения Supabase авторизация готова, а схема БД подготовлена для дальнейшего подключения realtime-сообщений.

## Сборка Android/iOS

Для публикационной сборки установи EAS:
`npm install -g eas-cli`
`eas login`
`eas build:configure`
`eas build --platform android`
или
`eas build --platform ios`

## Что уже есть

- экран входа/регистрации
- демо-режим
- список чатов
- экран личного чата
- отправка сообщений в локальном состоянии
- Supabase client
- SQL-схема профилей, чатов, участников и сообщений
- тёмный фирменный UI Dizzy
